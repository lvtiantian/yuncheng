<?php header("Content-Type:text/html;charset=utf-8");?>
	<div class="footer">
		<h2>Contact</h2>
		<div class="footer-grid-address">
			<p>Tel: 18234044810</p>
			<p>Email: <a class="email-link" href="#">793865535@qq.com</a></p>
		</div>
	</div>